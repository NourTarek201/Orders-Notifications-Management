package project;

import java.util.*;

import project.model.CustomerModel;
import project.model.Product;

public class SharedDatabase {
    public static Map<Integer, Product> products = new HashMap<>();
    public static Map<Integer, CustomerModel> customers = new HashMap<>();


    

}
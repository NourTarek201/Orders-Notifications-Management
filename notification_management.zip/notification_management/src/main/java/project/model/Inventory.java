package project.model;

// import org.springframework.web.bind.annotation.GetMapping;
import java.util.*;

public class Inventory {
    private int prodCnt;
    
    // Getter
    public int getProdCnt() {
        return prodCnt;
    }

    // Setter
    public void setProdCnt(int prodCnt) {
        this.prodCnt = prodCnt;
    }
    
}

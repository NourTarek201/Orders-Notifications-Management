package project.controller;

import project.SharedDatabase;
import project.model.Response;
import project.model.Product;
import project.service.InventoryService;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;


import java.util.*;

import org.springframework.stereotype.Controller;


@RestController
@RequestMapping("/api")
public class InventoryController {
    @Autowired
    private InventoryService InventoryService = new InventoryService();


    @GetMapping("/viewRemainProducts/{category}")
    int viewRemain(@PathVariable("category") String category){
        System.out.println("get remain");
        // System.out.println(service.getRemainProducts(category).get(0).getName());
        return InventoryService.getRemainProducts(category);
    }

    @GetMapping("/availableProducts")
    ArrayList<Product> getAllProducts(){
        return InventoryService.getAvailableProducts();
    }


    @PostMapping("/addProduct")
    Response addProduct(@RequestBody Product product){
        System.out.println("add product");
        boolean ser = InventoryService.newProduct(product);
        Response response = new Response();
        if (ser) {
            response.setStatus(true);
            response.setResult("Product Added Successfully");
        }

        else{
            response.setStatus(false);
            response.setResult("Couldn't add product");
        }
      
        return response;
    }

} 
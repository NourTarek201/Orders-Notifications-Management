package project.controller;


import project.SharedDatabase;
import project.model.CustomerModel;
import project.model.Response;
import project.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api")
public class CustomerController {

    @Autowired
    CustomerService customerService = new CustomerService();

    //login function
    @GetMapping("/login")
    public Response getMethodName(@RequestParam("id") int id, @RequestParam("password") String password) {
        Response response = new Response();
        if(customerService.isLogged(id,password)){
            response.setStatus(true);
            CustomerModel customer = customerService.getCustomer(id);

            response.setResult("Welcome "+customer.getName()+" You have logged in successfully" );
        }
        else{
            response.setStatus(false);
            response.setResult("Invalid credentials" );
        }
        return response;
    }



    

    @PostMapping("/addCustomer") // /person/add
    public Response addCustomer(@RequestBody CustomerModel customer) {
        boolean state = customerService.addCustomer(customer);
        Response response = new Response();
        if(state){
            response.setStatus(true);

            response.setResult("Customer added successfully");
        }
        else{
            response.setStatus(false);
            response.setResult("Customer already exists");
        }
        return response;
    }


    @GetMapping("/getCustomer/{id}")
    public Response getCustomer(@PathVariable("id") int id){
        CustomerModel customer = customerService.getCustomer(id);
        Response response = new Response();
        if(customer != null){
            response.setStatus(true);
            response.setResult(customer);
        }
        else{
            response.setStatus(false);
            response.setResult("Customer doesn't exist");
        }
        return response;
    }



    @GetMapping("/getAllCustomers")
    public Response getAllCustomers(){
        Response response = new Response();
        response.setStatus(true);
        response.setResult(customerService.getAllCustomers());
        return response;
    }



    @DeleteMapping("/deleteCustomer/{id}")
    public Response deletePerson(@PathVariable("id") int id){
        Response response = new Response();
        boolean status = customerService.deleteCustomer(id);
        if(status){
            response.setStatus(true);
            response.setResult("Customer deleted successfully");
        }
        else{
            response.setStatus(false);
            response.setResult("Customer doesn't exist");
        }
        return response;
    }

    
    @RequestMapping("*")
    public Response error(){
        Response response = new Response();
        response.setStatus(false);
        response.setResult("Invalid request");
        return response;
    }



}

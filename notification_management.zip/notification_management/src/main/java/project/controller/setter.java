package project.controller;

public @interface setter {

}
